//
//  MapTypes.m
//  uTrack
//
//  Created by U on 07/01/15.
//  Copyright (c) 2015 Unicode Systems Pvt. Ltd. All rights reserved.
//

#import "MapTypes.h"

@implementation MapTypes

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    
}


@end

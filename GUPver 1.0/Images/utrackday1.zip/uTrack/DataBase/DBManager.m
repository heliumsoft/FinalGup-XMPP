//
//  DBManager.m
//  michat
//
//  Created by Ram Krishna on 08/07/14.
//  Copyright (c) 2014 unicode. All rights reserved.
//

#import "DBManager.h"

static DBManager *sharedInstance = nil;
static sqlite3 *database = nil;
static sqlite3_stmt *statement = nil;

@implementation DBManager

+(DBManager*)getSharedInstance{
    if (!sharedInstance) {
        sharedInstance = [[super allocWithZone:NULL]init];
        [sharedInstance createDB];
    }
    return sharedInstance;
}


-(BOOL)createDB{
    NSString *docsDir;
    NSArray *dirPaths;
    // Get the documents directory
    dirPaths = NSSearchPathForDirectoriesInDomains
    (NSDocumentDirectory, NSUserDomainMask, YES);
    docsDir = dirPaths[0];
    // Build the path to the database file
    _databasePath = [[NSString alloc] initWithString:
                    [docsDir stringByAppendingPathComponent: @"ITRACK.sqlite"]];
    [[NSUserDefaults standardUserDefaults] setObject:_databasePath forKey:@"dbPath"];
     NSLog(@"DATA BASE:%@",_databasePath);
    BOOL isSuccess = YES;
    NSFileManager *filemgr = [NSFileManager defaultManager];
    if ([filemgr fileExistsAtPath: _databasePath ] == NO){
       
        const char *dbpath = [_databasePath UTF8String];
        if (sqlite3_open(dbpath, &database) == SQLITE_OK){
   
            char *errMsg;
            const char *prouser =
            "create table if not exists itrack(time TEXT, date TEXT,latitude TEXT,longitude TEXT)";
            
            if (sqlite3_exec(database, prouser, NULL, NULL, &errMsg) != SQLITE_OK){
                isSuccess = NO;
                NSLog(@"Failed to create table Login_user_data");
            }
           
            sqlite3_close(database);
            return  isSuccess;
        }else{
            isSuccess = NO;
            NSLog(@"Failed to open/create database");
        }
    }
    return isSuccess;
}

#pragma mark ---DataBase Action
- (BOOL) saveData:(NSArray*) field value:(NSArray*)value table:(NSString*)table{
    
    
    NSString * path = [[NSUserDefaults standardUserDefaults] objectForKey:@"dbPath"];
    const char *dbpath = [path UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK){
        
        NSString *insertSQL = [self composeInsertQuery:field value:value table:table];
        NSLog(@"%@",insertSQL);
        const char *insert_stmt = [insertSQL UTF8String];
        sqlite3_prepare_v2(database, insert_stmt,-1, &statement, NULL);
        if (sqlite3_step(statement) == SQLITE_DONE){
             return YES;
        } else {
            NSLog(@"ERROR:%s",sqlite3_errmsg(database));
             return NO;
        }
     sqlite3_reset(statement);
     sqlite3_close(database);
     }
     return NO;
}

-(BOOL) updateTable:(NSArray*) field value:(NSArray*)value table:(NSString*)table condition:(NSString*)condition{
    
    NSString * path = [[NSUserDefaults standardUserDefaults] objectForKey:@"dbPath"];
    const char *dbpath = [path UTF8String];
    
    if (sqlite3_open(dbpath, &database) == SQLITE_OK){
        
        NSString *query = [self composeUpdateQuery:field value:value table:table condition:condition];
        NSLog(@"%@",query);
        const char *insert_stmt = [query UTF8String];
        sqlite3_prepare_v2(database, insert_stmt,-1, &statement, NULL);
        if (sqlite3_step(statement) == SQLITE_DONE){
            return YES;
        } else {
            NSLog(@"ERROR:%s",sqlite3_errmsg(database));
            return NO;
        }
        sqlite3_reset(statement);
        sqlite3_close(database);
    }
    
    return NO;
}


- (NSMutableArray*)select:(NSArray*)field from:(NSString*)table where:(NSString*)condition{
    
    NSString * path = [[NSUserDefaults standardUserDefaults] objectForKey:@"dbPath"];
    const char *dbpath = [path UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK){
        
        NSString *querySQL = [self composeSelectQuery:field table:table condition:condition];
        NSLog(@"%@",querySQL);
        const char *query_stmt = [querySQL UTF8String];
        NSMutableArray *rosterArray = [[NSMutableArray alloc]init];
        if (sqlite3_prepare_v2(database,query_stmt, -1, &statement, NULL) == SQLITE_OK){
            while (sqlite3_step(statement) == SQLITE_ROW){
                NSMutableDictionary *rosterEntity = [[NSMutableDictionary alloc]init];
                for (int i=0; i<field.count; i++) {
                    NSString *jid = [[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(statement,i)];
                    [rosterEntity setObject:jid forKey:[field objectAtIndex:i]];
                }
                [rosterArray addObject:rosterEntity];
            }
            NSLog(@"%@",rosterArray);
            sqlite3_reset(statement);
            sqlite3_close(database);
            return rosterArray;
        }
    }
    return nil;
}

- (NSMutableArray*)getLastObjectOnly:(NSArray*)field from:(NSString*)table{
    
    NSString * path = [[NSUserDefaults standardUserDefaults] objectForKey:@"dbPath"];
    const char *dbpath = [path UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK){
        
        NSString *querySQL = [self getLastObject:field table:table];
        NSLog(@"%@",querySQL);
        const char *query_stmt = [querySQL UTF8String];
        NSMutableArray *rosterArray = [[NSMutableArray alloc]init];
        if (sqlite3_prepare_v2(database,query_stmt, -1, &statement, NULL) == SQLITE_OK){
            while (sqlite3_step(statement) == SQLITE_ROW){
                NSMutableDictionary *rosterEntity = [[NSMutableDictionary alloc]init];
                for (int i=0; i<field.count; i++) {
                    NSString *jid = [[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(statement,i)];
                    [rosterEntity setObject:jid forKey:[field objectAtIndex:i]];
                }
                [rosterArray addObject:rosterEntity];
            }
            NSLog(@"%@",rosterArray);
            sqlite3_reset(statement);
            sqlite3_close(database);
            return rosterArray;
        }
    }
    return nil;
}



- (void)Delete:(NSString*)table condition:(NSString*)condition{
    
    NSString * path = [[NSUserDefaults standardUserDefaults] objectForKey:@"dbPath"];
    const char *dbpath = [path UTF8String];
    
    if(sqlite3_open(dbpath, &database) == SQLITE_OK){
        NSString *sql;
        if(condition)
            sql = [NSString stringWithFormat:@"DELETE FROM %@ WHERE %@",table,condition];
        else
            sql = [NSString stringWithFormat:@"DELETE FROM %@",table];
        
        const char *insert_stmt = [sql UTF8String];
        sqlite3_stmt *statement;
        if(sqlite3_prepare_v2(database, insert_stmt,-1, &statement, NULL) == SQLITE_OK){
            sqlite3_step(statement);
        }
    }
}


#pragma mark ---Compose Query
/*
 *COMPOSING UPDATE DATA QUERY
 */
-(NSString*) composeUpdateQuery:(NSArray*) field value:(NSArray*)value table:(NSString*)table condition:(NSString*)condition{
    NSString *query = @"";
    
    if ([field count] != [value count]) {
        
    } else {
        
        query = [NSString stringWithFormat:@"%@ UPDATE %@ SET" ,query,table];
        for (int i = 0; i < [field count]; i++) {
            if (i != [field count] - 1){
                if([[value objectAtIndex:i] isKindOfClass:NSNumberFormatterNoStyle]){
                    query = [NSString stringWithFormat:@"%@ %@ = %@, ",query,[field objectAtIndex:i],[value objectAtIndex:i]];
                }else{
                query = [NSString stringWithFormat:@"%@ %@ = '%@', ",query,[field objectAtIndex:i],[value objectAtIndex:i]];
                }
            }else{
                if([[value objectAtIndex:i] isKindOfClass:NSNumberFormatterNoStyle]){
                    query = [NSString stringWithFormat:@"%@ %@ = %@ ",query,[field objectAtIndex:i],[value objectAtIndex:i]];
                }else{
                    query = [NSString stringWithFormat:@"%@ %@ = '%@' ",query,[field objectAtIndex:i],[value objectAtIndex:i]];
                }
            }
        }
    }
    if(condition)
        query = [NSString stringWithFormat:@"%@ WHERE %@ ",query,condition];
    
    return query;
    
}

/*
 *COMPOSING INSERT DATA QUERY
 */
-(NSString*) composeInsertQuery:(NSArray*) field value:(NSArray*)value table:(NSString*)table{

    NSString *query = @"";
    
    if ([field count] != [value count]) {
        
    } else {
        
        query = [NSString stringWithFormat:@"%@ INSERT INTO %@ (" ,query,table];
        for (int i = 0; i < [field count]; i++) {
            if (i != [field count] - 1)
                query = [NSString stringWithFormat:@"%@ %@, ",query,[field objectAtIndex:i]];
            else
                 query = [NSString stringWithFormat:@"%@ %@ ",query,[field objectAtIndex:i]];
        }
        query = [NSString stringWithFormat:@"%@ ) VALUES (",query];
        for (int i = 0; i < [value count]; i++) {
            if (i != [value count] - 1){
               
                    query = [NSString stringWithFormat:@"%@ \"%@\", ",query,[value objectAtIndex:i]];
                
            }else{
                    query = [NSString stringWithFormat:@"%@ \"%@\" ",query,[value objectAtIndex:i]];
                
            }
        }
    }
    query = [NSString stringWithFormat:@"%@ ) ",query];
    NSLog(@"INSERT QUERY:%@",query);
    return query;
}

/*
 *COMPOSING SELECT DATA QUERY
 */
-(NSString*) composeSelectQuery:(NSArray*)field table:(NSString*)table condition:(NSString*)condition{
    NSString *query = @"";
    if (!field || [field count]<=0) {
        query = [NSString stringWithFormat:@"%@ SELECT * FROM %@ " ,query,table];

    } else {
        query = [NSString stringWithFormat:@"%@ SELECT " ,query];
        
        for (int i = 0; i < [field count]; i++) {
            if (i != [field count] - 1)
                query = [NSString stringWithFormat:@"%@ %@, ",query,[field objectAtIndex:i]];
            else
                query = [NSString stringWithFormat:@"%@ %@ ",query,[field objectAtIndex:i]];
        }
         query = [NSString stringWithFormat:@"%@ FROM %@ ",query,table];
    }
    
     if(condition)
         query = [NSString stringWithFormat:@"%@ WHERE %@ ",query,condition];
         
    NSLog(@"SELECT QUERY:%@",query);
    return query;
   
}

- (NSString*)getLastObject:(NSArray*)field table:(NSString*)table{
    
    NSString *query = @"";
    if (!field || [field count]<=0) {
        query = [NSString stringWithFormat:@"%@ SELECT * FROM %@ " ,query,table];
        
    } else {
        query = [NSString stringWithFormat:@"%@ SELECT " ,query];
        
        for (int i = 0; i < [field count]; i++) {
            if (i != [field count] - 1)
                query = [NSString stringWithFormat:@"%@ %@, ",query,[field objectAtIndex:i]];
            else
                query = [NSString stringWithFormat:@"%@ %@ ",query,[field objectAtIndex:i]];
        }
        query = [NSString stringWithFormat:@"%@ FROM %@ ",query,table];
    }
    
        query = [NSString stringWithFormat:@"%@ ORDER BY date DESC LIMIT 1",query];
    
    NSLog(@"SELECT QUERY:%@",query);
    return query;
}

@end

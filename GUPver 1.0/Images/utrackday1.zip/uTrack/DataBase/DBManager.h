//
//  DBManager.h
//  ;
//
//  Created by Ram Krishna on 08/07/14.
//  Copyright (c) 2014 unicode. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>

@interface DBManager : NSObject{
 
    
    
}

@property(strong,nonatomic)NSString *databasePath;


+(DBManager*)getSharedInstance;
-(BOOL)createDB;
-(NSArray*)fetchData:(NSArray*) field table:(NSString*)table condition:(NSString*)condition;
-(BOOL)saveData:(NSArray*) field value:(NSArray*)value table:(NSString*)table;
-(BOOL) updateTable:(NSArray*) field value:(NSArray*)value table:(NSString*)table condition:(NSString*)condition;
- (void)Delete:(NSString*)table   condition:(NSString*)condition;
- (NSMutableArray*)select:(NSArray*)field from:(NSString*)table where:(NSString*)condition;
- (NSMutableArray*)getLastObjectOnly:(NSArray*)field from:(NSString*)table;
@end

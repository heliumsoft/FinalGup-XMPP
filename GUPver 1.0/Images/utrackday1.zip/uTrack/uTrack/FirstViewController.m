//
//  FirstViewController.m
//  uTrack
//
//  Created by U on 07/01/15.
//  Copyright (c) 2015 Unicode Systems Pvt. Ltd. All rights reserved.
//

#import "FirstViewController.h"

@interface FirstViewController ()
{
    CLLocationCoordinate2D  locationCoordinate;
    CLLocation *location;
    MKPointAnnotation  *point;
    
    
}
@end

@implementation FirstViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	
    [_mainMapView setDelegate:self];
    
    CLLocationCoordinate2D annotationCoord;
    
    annotationCoord.latitude = 47.640071;
    annotationCoord.longitude = -122.129598;
    
    point = [[MKPointAnnotation alloc] init];
    point.title = @"My Location";
    point.subtitle = @"This is my current location";
    
    
    MKCoordinateRegion  region= MKCoordinateRegionMakeWithDistance(annotationCoord,  0.5*METERS_PER_MILE, 0.5*METERS_PER_MILE);
        [_mainMapView setRegion:region animated:YES];
    point.coordinate=annotationCoord;
        [_mainMapView addAnnotation:point];
    
    
}


-(void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
    
    mapView.centerCoordinate= CLLocationCoordinate2DMake(userLocation.location.coordinate.latitude, userLocation.location.coordinate.longitude);
    point.coordinate=mapView.centerCoordinate;
    MKCoordinateRegion  region= MKCoordinateRegionMakeWithDistance(mapView.centerCoordinate,  0.5*METERS_PER_MILE, 0.5*METERS_PER_MILE);
    [mapView setRegion:region animated:YES];
    
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

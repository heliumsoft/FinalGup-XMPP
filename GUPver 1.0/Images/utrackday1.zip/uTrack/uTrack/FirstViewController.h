//
//  FirstViewController.h
//  uTrack
//
//  Created by U on 07/01/15.
//  Copyright (c) 2015 Unicode Systems Pvt. Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#define METERS_PER_MILE   1609.344

@interface FirstViewController : UIViewController<MKMapViewDelegate,MKAnnotation>
@property (weak, nonatomic) IBOutlet MKMapView *mainMapView;


@end

//
//  AppDelegate.h
//  uTrack
//
//  Created by U on 07/01/15.
//  Copyright (c) 2015 Unicode Systems Pvt. Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DBManager.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

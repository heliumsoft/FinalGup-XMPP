//
//  SecondViewController.h
//  uTrack
//
//  Created by U on 07/01/15.
//  Copyright (c) 2015 Unicode Systems Pvt. Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "DBManager.h"

@interface SecondViewController : UIViewController<MKMapViewDelegate>
@property (weak, nonatomic) IBOutlet MKMapView *plottingMapView;

@end

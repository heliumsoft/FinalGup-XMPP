//
//  SecondViewController.m
//  uTrack
//
//  Created by U on 07/01/15.
//  Copyright (c) 2015 Unicode Systems Pvt. Ltd. All rights reserved.
//

#import "SecondViewController.h"

@interface SecondViewController ()
{
    CLLocationCoordinate2D  locationCoordinate;
    CLLocation *location;
}
@end

@implementation SecondViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [_plottingMapView  setDelegate:self];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
